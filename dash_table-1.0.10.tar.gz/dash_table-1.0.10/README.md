# Dash Table

This dash-table is based on original [dash-table](https://github.com/plotly/dash-table) project.
The purpose of it is to add some features in which i think is interesting and make use of it before adding it as contribution in the original project.

## TODOS
- [x] Automatic page_size
    - The automatic page size defines the number of rows of the table based on his parent container
- [ ] Modern UI
    - A style that brokes the quadratic aspect of the table, allowing it to have a more cleanner design